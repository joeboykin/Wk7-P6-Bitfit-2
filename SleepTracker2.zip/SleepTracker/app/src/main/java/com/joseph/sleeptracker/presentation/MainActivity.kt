package com.joseph.sleeptracker.presentation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.joseph.sleeptracker.R
import com.joseph.sleeptracker.presentation.add.AddFragment
import com.joseph.sleeptracker.presentation.home.HomeFragment
import com.joseph.sleeptracker.presentation.home.ShareViewModel

class MainActivity : AppCompatActivity() {
    lateinit var shareViewModel: ShareViewModel
    private lateinit var homeFragment: HomeFragment


    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        shareViewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory(application)).get(ShareViewModel::class.java)

        homeFragment = HomeFragment()

        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)

        viewPager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount(): Int {
                return 2
            }

            override fun createFragment(position: Int): Fragment {
                return when (position) {
                    0 -> HomeFragment()
                    else -> AddFragment()
                }
            }
        }

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            when (position) {
                0 -> tab.text = "Daily History"
                else -> tab.text = "Add New"
            }
        }.attach()

    }

}