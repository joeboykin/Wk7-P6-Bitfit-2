package com.joseph.sleeptracker.presentation.home

import android.content.Context
import android.widget.TextView
import com.github.mikephil.charting.components.MarkerView
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.utils.MPPointF
import com.joseph.sleeptracker.R
import com.joseph.sleeptracker.data.model.SleepRecord

class SleepRecordMarkerView(
    context: Context,
    layoutResource: Int,
    private val sleepRecords: List<SleepRecord>
) : MarkerView(context, layoutResource) {

    private val dateTextView: TextView = findViewById(R.id.dateTextView)
    private val hoursTextView: TextView = findViewById(R.id.hoursTextView)
    private val moodTextView: TextView = findViewById(R.id.moodTextView)

    override fun refreshContent(entry: Entry?, highlight: Highlight?) {
        if (entry != null) {
            val sleepRecord = sleepRecords[entry.x.toInt()]
            dateTextView.text = "Date: ${sleepRecord.date}"
            hoursTextView.text = "Hours Slept: ${sleepRecord.hours}"
            moodTextView.text = "Mood: ${getMoodFromValue(sleepRecord.mood)}"
        }
        super.refreshContent(entry, highlight)
    }


    private fun getMoodFromValue(value: Int): String {
        return when (value) {
            in 9..10 -> "Good Sleep"
            in 7..8 -> "Feeling Refreshed"
            in 5..6 -> "Neutral"
            in 3..4 -> "Feeling Tired"
            in 1..2 -> "Bad Dreams"
            else -> "Neutral"
        }
    }
    override fun getOffsetForDrawingAtPoint(posX: Float, posY: Float): MPPointF {
        return MPPointF((-(width / 2)).toFloat(), -height.toFloat())
    }
}
