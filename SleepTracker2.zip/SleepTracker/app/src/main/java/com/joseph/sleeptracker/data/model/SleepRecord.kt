package com.joseph.sleeptracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity("sleep_record")
data class SleepRecord(
    val hours: Int,
    val mood: Int,
    @PrimaryKey
    val date: String
)
