package com.joseph.sleeptracker.presentation.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.joseph.sleeptracker.data.database.RecordDatabase
import com.joseph.sleeptracker.data.model.SleepRecord
import com.joseph.sleeptracker.domain.RecordRepository
import kotlinx.coroutines.launch

class ShareViewModel(application: Application) : AndroidViewModel(application) {

    private var repository: RecordRepository


    init {
        val dao = RecordDatabase.getInstance(application).sleepDao()
        repository = RecordRepository(dao)
    }

    private val _records = MutableLiveData<List<SleepRecord>>()
    val records: LiveData<List<SleepRecord>>
        get() = _records

    fun getAllRecords() {
        viewModelScope.launch {
            val acronyms = repository.getRecords()
            _records.postValue(acronyms)
        }
    }

    fun insert(sleepRecord: SleepRecord) = viewModelScope.launch {
        repository.insertRecord(sleepRecord = sleepRecord)
    }
}