package com.joseph.sleeptracker.presentation.add

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CalendarView
import android.widget.SeekBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.joseph.sleeptracker.R
import com.joseph.sleeptracker.data.model.SleepRecord
import com.joseph.sleeptracker.presentation.MainActivity
import com.joseph.sleeptracker.presentation.home.HomeFragment
import com.joseph.sleeptracker.presentation.home.ShareViewModel
import java.text.SimpleDateFormat
import java.util.*

class AddFragment : Fragment() {

    private lateinit var sharedViewModel: ShareViewModel
    private lateinit var saveBtn: Button
    private lateinit var hoursBar: SeekBar
    private lateinit var moodBar: SeekBar
    private lateinit var calendarView: CalendarView
    private lateinit var selectedDate: String
    private var hours: Int = -1
    private var mood: Int = -1
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add, container, false)
        hoursBar = view.findViewById(R.id.sleepHoursSlider)
        moodBar = view.findViewById(R.id.moodSlider)
        calendarView = view.findViewById(R.id.datePicker)
        saveBtn = view.findViewById(R.id.saveButton)
        sharedViewModel = (activity as MainActivity).shareViewModel
        // Get the current date in the desired format
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        val currentDate = dateFormat.format(Date())

// Set the current date as the default value for selectedDate
        selectedDate = currentDate

        initListeners()
        return view
    }

    private fun initListeners() {

        hoursBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                hours = progress
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        moodBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                mood = progress
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        saveBtn.setOnClickListener {
            if (mood != -1 && hours != -1) {
                sharedViewModel.insert(SleepRecord(hours, mood, selectedDate))
               // (activity as MainActivity).replaceFragment(HomeFragment())
            } else {
                Toast.makeText(
                    requireContext(),
                    "Please Select Hours, Your Feeling and Date",
                    Toast.LENGTH_SHORT
                ).show()
            }

        }

        // Add a listener for when the selected date changes
        calendarView.setOnDateChangeListener { view, year, month, dayOfMonth ->

            // Format the date in the desired format
            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.US)
            val date = Calendar.getInstance()
            date.set(year, month, dayOfMonth)
            val formattedDate = dateFormat.format(date.time)

            // Update a variable or TextView with the formatted date
            selectedDate = formattedDate
        }
    }
}