package com.joseph.sleeptracker.presentation.home

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.joseph.sleeptracker.R
import com.joseph.sleeptracker.data.model.SleepRecord
import com.joseph.sleeptracker.presentation.MainActivity

class HomeFragment : Fragment() {

    private lateinit var noRecord: TextView
    private lateinit var viewModel: ShareViewModel
    private lateinit var chart: LineChart

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_record, container, false)
        noRecord = view.findViewById(R.id.norecord)
        chart = view.findViewById(R.id.lineChart)
        viewModel = (activity as MainActivity).shareViewModel
        initViews()

        return view
    }

    private fun initViews() {

        viewModel.getAllRecords()

        viewModel.records.observe(viewLifecycleOwner) {
            setData(it)
            if (it.isNullOrEmpty()) {
                chart.visibility = View.GONE
                noRecord.visibility = View.VISIBLE
            } else {

                chart.visibility = View.VISIBLE
                noRecord.visibility = View.GONE
            }
        }

        getRecords()
    }


    private fun getRecords() {
        viewModel.getAllRecords()
        viewModel.records.observeForever {
            setData(it)

        }
    }

    private fun setData(sleepRecords: List<SleepRecord>) {
        val hoursEntries = mutableListOf<Entry>()
        val moodEntries = mutableListOf<Entry>()
        val xValues = mutableListOf<String>()

        for (i in sleepRecords.indices) {
            hoursEntries.add(Entry(i.toFloat(), sleepRecords[i].hours.toFloat()))
            moodEntries.add(Entry(i.toFloat(), sleepRecords[i].mood.toFloat()))
            xValues.add(sleepRecords[i].date)
        }

        val hoursDataSet = LineDataSet(hoursEntries, "Hours Slept")

        hoursDataSet.color = Color.BLUE
        hoursDataSet.valueTextColor = Color.BLACK
        hoursDataSet.valueTextSize = 15f

        val moodDataSet = LineDataSet(moodEntries, "Mood")
        moodDataSet.color = Color.RED
        moodDataSet.valueTextColor = Color.BLACK
        moodDataSet.valueTextSize = 15f

        val lineData = LineData(hoursDataSet, moodDataSet)
        chart.data = lineData

        val xAxis = chart.xAxis
        xAxis.valueFormatter = IndexAxisValueFormatter(xValues)
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.setDrawGridLines(false)
        xAxis.setDrawAxisLine(true)

        chart.axisLeft.setDrawGridLines(false)
        chart.axisRight.setDrawGridLines(false)
        chart.xAxis.setDrawGridLines(false)

        chart.description.isEnabled = false
        chart.legend.isEnabled = true
        chart.animateY(1000)

        val markerView = SleepRecordMarkerView(chart.context, R.layout.marker_view_layout, sleepRecords)
        chart.marker = markerView
    }
}